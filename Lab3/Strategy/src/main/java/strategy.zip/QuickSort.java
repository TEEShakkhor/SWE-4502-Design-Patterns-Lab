public class QuickSort implements SortingAlgorithm{
    @Override
    public void sort(int[] arr) {
        System.out.println("Sorting using Quick Sort");
    }
}
