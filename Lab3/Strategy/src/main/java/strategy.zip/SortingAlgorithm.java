public interface SortingAlgorithm {
    void sort(int[] arr);
}
